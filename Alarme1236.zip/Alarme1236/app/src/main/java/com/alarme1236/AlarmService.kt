package com.alarme1236

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.*

class AlarmService : Service() {
    private var mp: MediaPlayer? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("al", "Alarme", NotificationManager.IMPORTANCE_HIGH).apply { setSound(null, null) }
        )
        val full = PendingIntent.getActivity(
            this, 3, Intent(this, AlarmActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, "al")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Alarme")
            .setContentText("Toque para parar")
            .setCategory(Notification.CATEGORY_ALARM)
            .setFullScreenIntent(full, true)
            .setContentIntent(full)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
        else startForeground(1, n)

        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)
        play()
        Handler(Looper.getMainLooper()).postDelayed({ stopSelf() }, 10 * 60_000L)
        return START_NOT_STICKY
    }

    private fun start(u: Uri): Boolean = try {
        mp = MediaPlayer().apply {
            setAudioAttributes(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            )
            setWakeMode(this@AlarmService, PowerManager.PARTIAL_WAKE_LOCK)
            setDataSource(this@AlarmService, u)
            isLooping = true
            prepare()
            start()
        }
        true
    } catch (e: Exception) {
        mp?.release(); mp = null; false
    }

    private fun play() {
        mp?.release(); mp = null
        val uri = Prefs.music(this)?.let { Uri.parse(it) }
        if (uri == null || !start(uri))
            start(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
    }

    override fun onDestroy() {
        mp?.release(); mp = null
        super.onDestroy()
    }
}
