package com.alarme1236

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId

object Scheduler {
    fun next(c: Context): Long? {
        val limit = LocalDateTime.now().plusSeconds(30)
        var best: LocalDateTime? = null
        for (d in 0..3) {
            val date = LocalDate.now().plusDays(d.toLong())
            val w = Prefs.isWork(c, date)
            for (a in Prefs.alarms(c)) {
                if (!a.on || a.work != w) continue
                val t = date.atTime(a.h, a.m)
                if (t.isAfter(limit) && (best == null || t.isBefore(best))) best = t
            }
        }
        return best?.atZone(ZoneId.systemDefault())?.toInstant()?.toEpochMilli()
    }

    private fun pi(c: Context, code: Int): PendingIntent = PendingIntent.getBroadcast(
        c, code, Intent(c, AlarmReceiver::class.java),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun set(c: Context, time: Long, code: Int) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val show = PendingIntent.getActivity(
            c, 2, Intent(c, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        am.setAlarmClock(AlarmManager.AlarmClockInfo(time, show), pi(c, code))
    }

    fun schedule(c: Context) {
        val t = next(c)
        if (t == null) {
            (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi(c, 0))
        } else set(c, t, 0)
    }

    fun snooze(c: Context) = set(c, System.currentTimeMillis() + 5 * 60_000L, 1)
}
