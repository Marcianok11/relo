package com.alarme1236

import android.Manifest
import android.app.Activity
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private val fmt = DateTimeFormatter.ofPattern("dd/MM/yyyy")

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(40), dp(16), dp(32))
        }
        setContentView(ScrollView(this).apply { addView(root) })
        Scheduler.schedule(this)
        refresh()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun tv(t: String, size: Float) = TextView(this).apply {
        text = t; textSize = size; setPadding(0, dp(8), 0, dp(4))
    }

    private fun btn(t: String, f: () -> Unit) = Button(this).apply {
        text = t; setOnClickListener { f() }
    }

    private fun changed(list: List<Prefs.A>) {
        Prefs.saveAlarms(this, list); Scheduler.schedule(this); refresh()
    }

    private fun refresh() {
        root.removeAllViews()
        val w = Prefs.isWork(this, LocalDate.now())
        root.addView(tv("Alarme 12x36", 26f))
        root.addView(tv(if (w) "Hoje: TRABALHO" else "Hoje: FOLGA", 18f))
        val n = Scheduler.next(this)
        root.addView(tv(
            if (n == null) "Nenhum alarme ativo"
            else "Próximo: " + SimpleDateFormat("EEE dd/MM HH:mm", Locale("pt", "BR")).format(Date(n)), 16f
        ))

        root.addView(tv("Um dia em que você TRABALHA (referência):", 14f))
        val sd = LocalDate.ofEpochDay(Prefs.startDay(this))
        root.addView(btn(sd.format(fmt)) {
            DatePickerDialog(this, { _, y, m, d ->
                Prefs.setStartDay(this, LocalDate.of(y, m + 1, d).toEpochDay())
                Scheduler.schedule(this); refresh()
            }, sd.year, sd.monthValue - 1, sd.dayOfMonth).show()
        })

        root.addView(tv("Alarmes:", 16f))
        val list = Prefs.alarms(this)
        list.forEachIndexed { i, a ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(btn("%02d:%02d".format(a.h, a.m)) {
                TimePickerDialog(this, { _, h, m -> a.h = h; a.m = m; changed(list) }, a.h, a.m, true).show()
            })
            row.addView(btn(if (a.work) "Trabalho" else "Folga") { a.work = !a.work; changed(list) })
            row.addView(Switch(this).apply {
                isChecked = a.on
                setOnCheckedChangeListener { _, v -> a.on = v; changed(list) }
            })
            row.addView(btn("✕") { list.removeAt(i); changed(list) })
            root.addView(row)
        }
        root.addView(btn("+ Adicionar alarme") { list.add(Prefs.A(6, 0, true, true)); changed(list) })

        root.addView(tv("Música:", 16f))
        val m = Prefs.music(this)
        root.addView(tv(if (m == null) "Padrão do celular" else Uri.parse(m).lastPathSegment ?: "Escolhida", 13f))
        root.addView(btn("Escolher música da galeria") {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "audio/*"
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            }, 10)
        })
        root.addView(btn("Testar alarme agora") {
            startForegroundService(Intent(this, AlarmService::class.java))
            startActivity(Intent(this, AlarmActivity::class.java))
        })
        root.addView(btn("Liberar uso de bateria (recomendado)") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })
    }

    @Deprecated("simple")
    override fun onActivityResult(r: Int, res: Int, d: Intent?) {
        super.onActivityResult(r, res, d)
        val u = d?.data ?: return
        if (r == 10 && res == RESULT_OK) {
            try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (e: Exception) {}
            Prefs.setMusic(this, u.toString()); refresh()
        }
    }
}
