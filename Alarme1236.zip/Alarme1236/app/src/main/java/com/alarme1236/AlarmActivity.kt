package com.alarme1236

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class AlarmActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        val l = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#B91C1C"))
            setPadding(48, 48, 48, 48)
        }
        l.addView(TextView(this).apply {
            text = "⏰ Hora de acordar"
            textSize = 32f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        })
        l.addView(Button(this).apply {
            text = "PARAR"; textSize = 22f
            setOnClickListener { stopService(Intent(this@AlarmActivity, AlarmService::class.java)); finish() }
        })
        l.addView(Button(this).apply {
            text = "Soneca 5 min"; textSize = 18f
            setOnClickListener {
                stopService(Intent(this@AlarmActivity, AlarmService::class.java))
                Scheduler.snooze(this@AlarmActivity); finish()
            }
        })
        setContentView(l)
    }
}
