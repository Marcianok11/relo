package com.alarme1236

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        Scheduler.schedule(c) // já agenda o próximo plantão
        c.startForegroundService(Intent(c, AlarmService::class.java))
    }
}
