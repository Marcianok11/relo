package com.alarme1236

import android.content.Context
import java.time.LocalDate

object Prefs {
    data class A(var h: Int, var m: Int, var work: Boolean, var on: Boolean)

    private fun sp(c: Context) = c.getSharedPreferences("p", Context.MODE_PRIVATE)

    fun startDay(c: Context): Long = sp(c).getLong("start", LocalDate.now().toEpochDay())
    fun setStartDay(c: Context, d: Long) = sp(c).edit().putLong("start", d).apply()

    fun music(c: Context): String? = sp(c).getString("music", null)
    fun setMusic(c: Context, s: String?) = sp(c).edit().putString("music", s).apply()

    fun alarms(c: Context): MutableList<A> {
        val s = sp(c).getString("al", "6:0:1:1") ?: ""
        if (s.isEmpty()) return mutableListOf()
        return s.split(";").map {
            val p = it.split(":")
            A(p[0].toInt(), p[1].toInt(), p[2] == "1", p[3] == "1")
        }.toMutableList()
    }

    fun saveAlarms(c: Context, l: List<A>) {
        val s = l.joinToString(";") { "${it.h}:${it.m}:${if (it.work) 1 else 0}:${if (it.on) 1 else 0}" }
        sp(c).edit().putString("al", s).apply()
    }

    // Dia de trabalho = diferença de dias em relação à data de referência é par (12x36)
    fun isWork(c: Context, d: LocalDate): Boolean =
        Math.floorMod(d.toEpochDay() - startDay(c), 2L) == 0L
}
